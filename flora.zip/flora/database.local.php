<?php
// Sao chép thành database.local.php và điền thông tin trên máy của bạn.
return [
    'host' => 'localhost',
    'username' => 'root',
    'password' => '',
    'database' => 'flora',
    'port' => 3306,
];
