<?php
declare(strict_types=1);

final class ReportModel
{
    public function __construct(private mysqli $db) {}

    public function getOverview(string $from, string $to): array
    {
        $stmt = $this->db->prepare(
            "SELECT COUNT(*) AS completed_orders,
                    COUNT(DISTINCT user_id) AS customers,
                    COALESCE(SUM(subtotal - coupon_discount), 0) AS merchandise_revenue
             FROM orders
             WHERE status = 'completed'
               AND completed_at >= ?
               AND completed_at < DATE_ADD(?, INTERVAL 1 DAY)"
        );
        $stmt->bind_param('ss', $from, $to);
        $stmt->execute();
        $row = $stmt->get_result()->fetch_assoc();
        $stmt->close();
        return $row ?: ['completed_orders' => 0, 'customers' => 0, 'merchandise_revenue' => 0];
    }

    public function getCompletedOrders(string $from, string $to, int $limit = 100): array
    {
        $limit = max(1, min(500, $limit));
        $stmt = $this->db->prepare(
            "SELECT o.id, o.order_code, o.completed_at, u.full_name,
                    o.subtotal - o.coupon_discount AS merchandise_amount
             FROM orders o
             INNER JOIN users u ON u.id = o.user_id
             WHERE o.status = 'completed'
               AND o.completed_at >= ?
               AND o.completed_at < DATE_ADD(?, INTERVAL 1 DAY)
             ORDER BY o.completed_at DESC, o.id DESC
             LIMIT ?"
        );
        $stmt->bind_param('ssi', $from, $to, $limit);
        $stmt->execute();
        $rows = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
        $stmt->close();
        return $rows;
    }

    public function getSalesRanking(string $from, string $to, bool $bestSelling): array
    {
        $orderBy = $bestSelling
            ? 'units_sold DESC, merchandise_revenue DESC, p.id DESC'
            : 'units_sold ASC, p.id ASC';
        $stmt = $this->db->prepare(
            "SELECT p.id, p.name, p.status,
                    COALESCE(s.units_sold, 0) AS units_sold,
                    COALESCE(s.order_count, 0) AS order_count,
                    COALESCE(s.merchandise_revenue, 0) AS merchandise_revenue
             FROM products p
             LEFT JOIN (
                 SELECT v.product_id,
                        SUM(oi.quantity) AS units_sold,
                        COUNT(DISTINCT o.id) AS order_count,
                        SUM(oi.quantity * oi.unit_price) AS merchandise_revenue
                 FROM order_items oi
                 INNER JOIN orders o ON o.id = oi.order_id
                 INNER JOIN product_variants v ON v.id = oi.variant_id
                 WHERE o.status = 'completed'
                   AND o.completed_at >= ?
                   AND o.completed_at < DATE_ADD(?, INTERVAL 1 DAY)
                 GROUP BY v.product_id
             ) s ON s.product_id = p.id
             ORDER BY {$orderBy}
             LIMIT 10"
        );
        $stmt->bind_param('ss', $from, $to);
        $stmt->execute();
        $rows = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
        $stmt->close();
        return $rows;
    }

    public function getLowStockVariants(int $limit = 50): array
    {
        $limit = max(1, min(200, $limit));
        $stmt = $this->db->prepare(
            "SELECT p.id AS product_id, p.name AS product_name,
                    v.id AS variant_id, sz.name AS size_name,
                    col.name AS color_name, v.stock
             FROM product_variants v
             INNER JOIN products p ON p.id = v.product_id
             INNER JOIN sizes sz ON sz.id = v.size_id
             INNER JOIN colors col ON col.id = v.color_id
             WHERE p.status = 'active'
               AND v.status = 'active'
               AND v.stock <= 5
             ORDER BY v.stock ASC, p.name, col.name, sz.sort_order
             LIMIT ?"
        );
        $stmt->bind_param('i', $limit);
        $stmt->execute();
        $rows = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
        $stmt->close();
        return $rows;
    }

    public function getEventSummary(string $from, string $to): array
    {
        $stmt = $this->db->prepare(
            "SELECT e.event_type,
                    COUNT(*) AS event_count,
                    COUNT(DISTINCT CASE
                        WHEN e.user_id IS NULL THEN CONCAT('s:', e.session_key)
                        ELSE CONCAT('u:', e.user_id)
                    END) AS people_count,
                    CASE WHEN e.event_type = 'search' THEN
                        (SELECT COUNT(*)
                         FROM orders o
                         WHERE o.status = 'completed'
                           AND o.completed_at >= ?
                           AND o.completed_at < DATE_ADD(?, INTERVAL 1 DAY)
                           AND EXISTS (
                               SELECT 1 FROM user_events se
                               WHERE se.event_type = 'search'
                                 AND se.user_id = o.user_id
                                 AND se.created_at >= ?
                                 AND se.created_at < DATE_ADD(?, INTERVAL 1 DAY)
                           ))
                    ELSE
                        (SELECT COUNT(DISTINCT o.id)
                         FROM orders o
                         WHERE o.status = 'completed'
                           AND o.completed_at >= ?
                           AND o.completed_at < DATE_ADD(?, INTERVAL 1 DAY)
                           AND EXISTS (
                               SELECT 1
                               FROM order_items oi
                               INNER JOIN product_variants v ON v.id = oi.variant_id
                               WHERE oi.order_id = o.id
                                 AND EXISTS (
                                     SELECT 1 FROM user_events pe
                                     WHERE pe.event_type = e.event_type
                                       AND pe.product_id = v.product_id
                                       AND pe.created_at >= ?
                                       AND pe.created_at < DATE_ADD(?, INTERVAL 1 DAY)
                                 )
                           ))
                    END AS order_count
             FROM user_events e
             WHERE e.created_at >= ?
               AND e.created_at < DATE_ADD(?, INTERVAL 1 DAY)
             GROUP BY e.event_type
             ORDER BY FIELD(e.event_type, 'view_product', 'search', 'add_to_cart')"
        );
        $stmt->bind_param('ssssssssss', $from, $to, $from, $to, $from, $to, $from, $to, $from, $to);
        $stmt->execute();
        $rows = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
        $stmt->close();
        return $rows;
    }

    public function getProductEventStats(string $eventType, string $from, string $to): array
    {
        if (!in_array($eventType, ['view_product', 'add_to_cart'], true)) {
            throw new InvalidArgumentException('Loại sự kiện sản phẩm không hợp lệ.');
        }
        $stmt = $this->db->prepare(
            "SELECT e.product_id, p.name AS product_name,
                    COUNT(*) AS event_count,
                    COUNT(DISTINCT CASE
                        WHEN e.user_id IS NULL THEN CONCAT('s:', e.session_key)
                        ELSE CONCAT('u:', e.user_id)
                    END) AS people_count,
                    (SELECT COUNT(DISTINCT o.id)
                     FROM orders o
                     WHERE o.status = 'completed'
                       AND o.completed_at >= ?
                       AND o.completed_at < DATE_ADD(?, INTERVAL 1 DAY)
                       AND EXISTS (
                           SELECT 1
                           FROM order_items oi
                           INNER JOIN product_variants v ON v.id = oi.variant_id
                           WHERE oi.order_id = o.id AND v.product_id = e.product_id
                       )) AS order_count
             FROM user_events e
             INNER JOIN products p ON p.id = e.product_id
             WHERE e.event_type = ?
               AND e.created_at >= ?
               AND e.created_at < DATE_ADD(?, INTERVAL 1 DAY)
             GROUP BY e.product_id, p.name
             ORDER BY event_count DESC, p.name
             LIMIT 20"
        );
        $stmt->bind_param('sssss', $from, $to, $eventType, $from, $to);
        $stmt->execute();
        $rows = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
        $stmt->close();
        return $rows;
    }

    public function getTopSearches(string $from, string $to): array
    {
        $stmt = $this->db->prepare(
            "SELECT e.search_keyword,
                    COUNT(*) AS event_count,
                    COUNT(DISTINCT CASE
                        WHEN e.user_id IS NULL THEN CONCAT('s:', e.session_key)
                        ELSE CONCAT('u:', e.user_id)
                    END) AS people_count,
                    (SELECT COUNT(*)
                     FROM orders o
                     WHERE o.status = 'completed'
                       AND o.completed_at >= ?
                       AND o.completed_at < DATE_ADD(?, INTERVAL 1 DAY)
                       AND EXISTS (
                           SELECT 1 FROM user_events se
                           WHERE se.event_type = 'search'
                             AND se.search_keyword = e.search_keyword
                             AND se.user_id = o.user_id
                             AND se.created_at >= ?
                             AND se.created_at < DATE_ADD(?, INTERVAL 1 DAY)
                       )) AS order_count
             FROM user_events e
             WHERE e.event_type = 'search'
               AND e.created_at >= ?
               AND e.created_at < DATE_ADD(?, INTERVAL 1 DAY)
             GROUP BY e.search_keyword
             ORDER BY event_count DESC, e.search_keyword
             LIMIT 20"
        );
        $stmt->bind_param('ssssss', $from, $to, $from, $to, $from, $to);
        $stmt->execute();
        $rows = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
        $stmt->close();
        return $rows;
    }
}
