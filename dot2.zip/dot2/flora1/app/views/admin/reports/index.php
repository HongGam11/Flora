<?php
$from ??= '';
$to ??= '';
$overview ??= ['completed_orders' => 0, 'customers' => 0, 'merchandise_revenue' => 0];
$completedOrders ??= [];
$bestSelling ??= [];
$slowSelling ??= [];
$lowStock ??= [];
$eventSummary ??= [];
$viewedProducts ??= [];
$cartedProducts ??= [];
$searches ??= [];

$eventLabels = [
    'view_product' => 'Lượt xem sản phẩm',
    'search' => 'Tìm kiếm',
    'add_to_cart' => 'Lượt thêm giỏ',
];
?>
<section class="admin-card tv3-catalog flora-reports">
    <h1>Báo cáo cửa hàng</h1>
    <form method="get" action="index.php" class="report-filter">
        <input type="hidden" name="route" value="admin_reports">
        <label>Từ ngày (UTC)<input type="date" name="from" value="<?= e($from) ?>" required></label>
        <label>Đến ngày (UTC)<input type="date" name="to" value="<?= e($to) ?>" required></label>
        <button type="submit">Lọc báo cáo</button>
    </form>

    <div class="report-kpis">
        <article><span>Đơn hoàn tất</span><strong><?= number_format((int) $overview['completed_orders']) ?></strong></article>
        <article><span>Khách đặt đơn</span><strong><?= number_format((int) $overview['customers']) ?></strong></article>
        <article><span>Doanh thu hàng hóa</span><strong><?= flora_money($overview['merchandise_revenue']) ?></strong></article>
    </div>
    <p class="report-note">Chỉ tính đơn có trạng thái hoàn tất theo ngày hoàn tất. Doanh thu bằng tổng tiền hàng trừ giảm giá đơn, không gồm phí giao hàng.</p>

    <h2>Đơn hoàn tất trong kỳ</h2>
    <?php if ($completedOrders): ?>
        <div class="tv3-scroll"><table>
            <thead><tr><th>Mã đơn</th><th>Khách hàng</th><th>Hoàn tất (UTC)</th><th>Tiền hàng</th></tr></thead>
            <tbody><?php foreach ($completedOrders as $order): ?>
                <tr>
                    <td><?= e($order['order_code']) ?></td>
                    <td><?= e($order['full_name']) ?></td>
                    <td><?= e($order['completed_at']) ?></td>
                    <td><?= flora_money($order['merchandise_amount']) ?></td>
                </tr>
            <?php endforeach; ?></tbody>
        </table></div>
        <p class="report-note">Danh sách hiển thị tối đa 100 đơn mới hoàn tất; KPI và doanh thu tính toàn bộ kỳ lọc.</p>
    <?php else: ?><p>Không có đơn hoàn tất trong kỳ.</p><?php endif; ?>

    <div class="report-columns">
        <div>
            <h2>Bán chạy</h2>
            <div class="tv3-scroll"><table>
                <thead><tr><th>Sản phẩm</th><th>Số lượng</th><th>Số đơn</th><th>Tiền hàng</th></tr></thead>
                <tbody><?php if ($bestSelling): foreach ($bestSelling as $product): ?>
                    <tr><td><?= e($product['name']) ?></td><td><?= number_format((int) $product['units_sold']) ?></td>
                        <td><?= number_format((int) $product['order_count']) ?></td>
                        <td><?= flora_money($product['merchandise_revenue']) ?></td></tr>
                <?php endforeach; else: ?><tr><td colspan="4">Chưa có sản phẩm.</td></tr><?php endif; ?></tbody>
            </table></div>
        </div>
        <div>
            <h2>Bán thấp (gồm cả 0)</h2>
            <div class="tv3-scroll"><table>
                <thead><tr><th>Sản phẩm</th><th>Trạng thái</th><th>Số lượng</th></tr></thead>
                <tbody><?php if ($slowSelling): foreach ($slowSelling as $product): ?>
                    <tr><td><?= e($product['name']) ?></td><td><?= e($product['status']) ?></td>
                        <td><?= number_format((int) $product['units_sold']) ?></td></tr>
                <?php endforeach; else: ?><tr><td colspan="3">Chưa có sản phẩm.</td></tr><?php endif; ?></tbody>
            </table></div>
        </div>
    </div>

    <h2>Tồn thấp (tồn hiện tại ≤ 5)</h2>
    <?php if ($lowStock): ?>
        <div class="tv3-scroll"><table>
            <thead><tr><th>Sản phẩm</th><th>Màu</th><th>Kích thước</th><th>Tồn hiện tại</th></tr></thead>
            <tbody><?php foreach ($lowStock as $variant): ?>
                <tr><td><?= e($variant['product_name']) ?></td><td><?= e($variant['color_name']) ?></td>
                    <td><?= e($variant['size_name']) ?></td><td><?= number_format((int) $variant['stock']) ?></td></tr>
            <?php endforeach; ?></tbody>
        </table></div>
    <?php else: ?><p>Không có biến thể đang bán nào có tồn kho ≤ 5.</p><?php endif; ?>

    <h2>Sự kiện, người và đơn hoàn tất</h2>
    <p class="report-note">Người là tài khoản duy nhất; khách chưa đăng nhập được đếm theo session. Đơn tìm kiếm ghép với tài khoản đã tìm trong kỳ; đơn xem/thêm giỏ là đơn hoàn tất có sản phẩm tương ứng.</p>
    <div class="tv3-scroll"><table>
        <thead><tr><th>Loại sự kiện</th><th>Số sự kiện</th><th>Số người</th><th>Số đơn</th></tr></thead>
        <tbody><?php if ($eventSummary): foreach ($eventSummary as $row): ?>
            <tr><td><?= e($eventLabels[$row['event_type']] ?? $row['event_type']) ?></td>
                <td><?= number_format((int) $row['event_count']) ?></td>
                <td><?= number_format((int) $row['people_count']) ?></td>
                <td><?= number_format((int) $row['order_count']) ?></td></tr>
        <?php endforeach; else: ?><tr><td colspan="4">Chưa ghi nhận sự kiện trong kỳ.</td></tr><?php endif; ?></tbody>
    </table></div>

    <div class="report-columns">
        <div>
            <h2>Sản phẩm được xem</h2>
            <div class="tv3-scroll"><table>
                <thead><tr><th>Sản phẩm</th><th>Sự kiện</th><th>Người</th><th>Đơn</th></tr></thead>
                <tbody><?php if ($viewedProducts): foreach ($viewedProducts as $product): ?>
                    <tr><td><?= e($product['product_name']) ?></td><td><?= number_format((int) $product['event_count']) ?></td>
                        <td><?= number_format((int) $product['people_count']) ?></td><td><?= number_format((int) $product['order_count']) ?></td></tr>
                <?php endforeach; else: ?><tr><td colspan="4">Chưa có lượt xem.</td></tr><?php endif; ?></tbody>
            </table></div>
        </div>
        <div>
            <h2>Sản phẩm được thêm giỏ</h2>
            <div class="tv3-scroll"><table>
                <thead><tr><th>Sản phẩm</th><th>Sự kiện</th><th>Người</th><th>Đơn</th></tr></thead>
                <tbody><?php if ($cartedProducts): foreach ($cartedProducts as $product): ?>
                    <tr><td><?= e($product['product_name']) ?></td><td><?= number_format((int) $product['event_count']) ?></td>
                        <td><?= number_format((int) $product['people_count']) ?></td><td><?= number_format((int) $product['order_count']) ?></td></tr>
                <?php endforeach; else: ?><tr><td colspan="4">Chưa có lượt thêm giỏ.</td></tr><?php endif; ?></tbody>
            </table></div>
        </div>
    </div>

    <h2>Từ khóa tìm kiếm</h2>
    <div class="tv3-scroll"><table>
        <thead><tr><th>Từ khóa</th><th>Sự kiện</th><th>Người</th><th>Đơn hoàn tất</th></tr></thead>
        <tbody><?php if ($searches): foreach ($searches as $search): ?>
            <tr><td><?= e($search['search_keyword']) ?></td><td><?= number_format((int) $search['event_count']) ?></td>
                <td><?= number_format((int) $search['people_count']) ?></td><td><?= number_format((int) $search['order_count']) ?></td></tr>
        <?php endforeach; else: ?><tr><td colspan="4">Chưa có từ khóa tìm kiếm.</td></tr><?php endif; ?></tbody>
    </table></div>
</section>
