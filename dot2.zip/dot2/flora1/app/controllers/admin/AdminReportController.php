<?php
declare(strict_types=1);

require_once APP_ROOT . '/app/models/ReportModel.php';

final class AdminReportController
{
    private mysqli $db;

    public function __construct()
    {
        Auth::requireRole(['admin']);
        require APP_ROOT . '/database.php';
        $this->db = $conn;
    }

    public function index(): void
    {
        [$from, $to] = $this->dateRange();
        $reports = new ReportModel($this->db);
        $overview = $reports->getOverview($from, $to);
        $completedOrders = $reports->getCompletedOrders($from, $to);
        $bestSelling = $reports->getSalesRanking($from, $to, true);
        $slowSelling = $reports->getSalesRanking($from, $to, false);
        $lowStock = $reports->getLowStockVariants();
        $eventSummary = $reports->getEventSummary($from, $to);
        $viewedProducts = $reports->getProductEventStats('view_product', $from, $to);
        $cartedProducts = $reports->getProductEventStats('add_to_cart', $from, $to);
        $searches = $reports->getTopSearches($from, $to);

        $title = 'Báo cáo | Flora';
        flora_catalog_page('reports/index', compact(
            'from',
            'to',
            'overview',
            'completedOrders',
            'bestSelling',
            'slowSelling',
            'lowStock',
            'eventSummary',
            'viewedProducts',
            'cartedProducts',
            'searches'
        ));
    }

    private function dateRange(): array
    {
        $today = new DateTimeImmutable('today', new DateTimeZone('UTC'));
        $from = $this->parseDate($_GET['from'] ?? null, $today->modify('-29 days')->format('Y-m-d'));
        $to = $this->parseDate($_GET['to'] ?? null, $today->format('Y-m-d'));
        if ($from > $to) {
            http_response_code(400);
            exit('Ngày bắt đầu phải trước hoặc bằng ngày kết thúc.');
        }
        return [$from, $to];
    }

    private function parseDate(mixed $value, string $default): string
    {
        if ($value === null || $value === '') {
            return $default;
        }
        if (!is_string($value)) {
            http_response_code(400);
            exit('Ngày báo cáo không hợp lệ.');
        }
        $date = DateTimeImmutable::createFromFormat('!Y-m-d', $value, new DateTimeZone('UTC'));
        $errors = DateTimeImmutable::getLastErrors();
        if ($date === false
            || ($errors !== false && ($errors['warning_count'] > 0 || $errors['error_count'] > 0))
            || $date->format('Y-m-d') !== $value) {
            http_response_code(400);
            exit('Ngày báo cáo không hợp lệ.');
        }
        return $value;
    }
}
