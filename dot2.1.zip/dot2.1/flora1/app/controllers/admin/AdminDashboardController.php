<?php

final class AdminDashboardController
{
    public function index(): void
    {
        Auth::requireRole(['admin']);

        require APP_ROOT . '/database.php';
        $to = new DateTimeImmutable('today', new DateTimeZone('UTC'));
        $from = $to->modify('-29 days');
        $summary = (new ReportModel($conn))->getOverview(
            $from->format('Y-m-d'),
            $to->format('Y-m-d')
        );
        $from = $from->format('Y-m-d');
        $to = $to->format('Y-m-d');
        flora_catalog_page('dashboard/index', compact('summary', 'from', 'to'));
    }
}