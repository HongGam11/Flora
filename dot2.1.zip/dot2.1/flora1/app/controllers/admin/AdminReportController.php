<?php
declare(strict_types=1);

require_once APP_ROOT . '/app/models/ReportModel.php';

final class AdminReportController
{
    private mysqli $db;

    public function __construct()
    {
        Auth::requireRole(['admin']);
        require APP_ROOT . '/database.php';
        $this->db = $conn;
    }

    public function index(): void
    {
        [$from, $to, $period] = $this->dateRange();
        $reports = new ReportModel($this->db);
        $overview = $reports->getOverview($from, $to);
        $rangeDays = (int) (new DateTimeImmutable($from, new DateTimeZone('UTC')))
            ->diff(new DateTimeImmutable($to, new DateTimeZone('UTC')))->days + 1;
        $previousTo = (new DateTimeImmutable($from, new DateTimeZone('UTC')))
            ->modify('-1 day')->format('Y-m-d');
        $previousFrom = (new DateTimeImmutable($previousTo, new DateTimeZone('UTC')))
            ->modify('-' . ($rangeDays - 1) . ' days')->format('Y-m-d');
        $previousOverview = $reports->getOverview($previousFrom, $previousTo);
        $previousOrderStatuses = $reports->getOrderStatusSummary($previousFrom, $previousTo);
        $dailySales = $reports->getDailySales($from, $to);
        $orderStatuses = $reports->getOrderStatusSummary($from, $to);
        $categorySales = $reports->getCategorySales($from, $to);
        $completedOrders = $reports->getCompletedOrders($from, $to);
        $bestSelling = $reports->getSalesRanking($from, $to, true);
        $slowSelling = $reports->getSalesRanking($from, $to, false);
        $lowStock = $reports->getLowStockVariants();
        $eventSummary = $reports->getEventSummary($from, $to);
        $viewedProducts = $reports->getProductEventStats('view_product', $from, $to);
        $cartedProducts = $reports->getProductEventStats('add_to_cart', $from, $to);
        $searches = $reports->getTopSearches($from, $to);

        $title = 'Báo cáo | Flora';
        flora_catalog_page('reports/index', compact(
            'from',
            'to',
            'period',
            'overview',
            'previousOverview',
            'previousOrderStatuses',
            'dailySales',
            'orderStatuses',
            'categorySales',
            'completedOrders',
            'bestSelling',
            'slowSelling',
            'lowStock',
            'eventSummary',
            'viewedProducts',
            'cartedProducts',
            'searches'
        ));
    }

    private function dateRange(): array
    {
        $today = new DateTimeImmutable('today', new DateTimeZone('UTC'));
        $requestedPeriod = $_GET['period'] ?? null;
        $period = is_string($requestedPeriod) ? $requestedPeriod : '';

        if ($period === '' && (isset($_GET['from']) || isset($_GET['to']))) {
            $period = 'custom';
        } elseif (!in_array($period, ['today', '7d', '30d', '90d', 'custom'], true)) {
            $period = '30d';
        }

        if ($period === 'custom') {
            $from = $this->parseDate($_GET['from'] ?? null, $today->modify('-29 days')->format('Y-m-d'));
            $to = $this->parseDate($_GET['to'] ?? null, $today->format('Y-m-d'));
        } else {
            $days = ['today' => 1, '7d' => 7, '30d' => 30, '90d' => 90][$period];
            $from = $today->modify('-' . ($days - 1) . ' days')->format('Y-m-d');
            $to = $today->format('Y-m-d');
        }
        if ($from > $to) {
            http_response_code(400);
            exit('Ngày bắt đầu phải trước hoặc bằng ngày kết thúc.');
        }
        return [$from, $to, $period];
    }

    private function parseDate(mixed $value, string $default): string
    {
        if ($value === null || $value === '') {
            return $default;
        }
        if (!is_string($value)) {
            http_response_code(400);
            exit('Ngày báo cáo không hợp lệ.');
        }
        $date = DateTimeImmutable::createFromFormat('!Y-m-d', $value, new DateTimeZone('UTC'));
        $errors = DateTimeImmutable::getLastErrors();
        if ($date === false
            || ($errors !== false && ($errors['warning_count'] > 0 || $errors['error_count'] > 0))
            || $date->format('Y-m-d') !== $value) {
            http_response_code(400);
            exit('Ngày báo cáo không hợp lệ.');
        }
        return $value;
    }
}
