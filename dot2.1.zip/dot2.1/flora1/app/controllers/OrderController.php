<?php
require_once APP_ROOT . '/app/models/OrderModel.php';
require_once APP_ROOT . '/app/services/OrderService.php';
final class OrderController
{
    private mysqli $conn;
    private OrderModel $orders;
    public function __construct()
    {
        Auth::requireLogin();
        require APP_ROOT . '/database.php';
        $this->conn = $conn;
        $this->orders = new OrderModel($conn);
    }
    public function index(): void
    {
        $userId = (int)Auth::user()['id'];
        $status = $_GET['status'] ?? '';
        $status = is_string($status) && in_array($status,['pending','confirmed','shipping','completed','cancelled'],true) ? $status : '';
        $orders = $this->orders->getOrdersByUser($userId, $status !== '' ? $status : null);
        $title = 'Đơn hàng của tôi | Flora';
        $cartCount = ProductModel::cartCount($this->conn, $userId);
        $categories = CategoryModel::all($this->conn);
        require APP_ROOT . '/app/views/layouts/header.php';
        require APP_ROOT . '/app/views/orders/index.php';
        require APP_ROOT . '/app/views/layouts/footer.php';
    }
    public function detail(): void
    {
        $userId = (int)Auth::user()['id'];
        $id = $_GET['id'] ?? null;
        if (!is_string($id) || !ctype_digit($id) || (int)$id<1) flora_catalog_notFound();
        $order = $this->orders->findByIdAndUser((int)$id, $userId);
        if (!$order) flora_catalog_notFound();
        $items = $this->orders->getOrderItems((int)$order['id']);
        $history = $this->orders->getOrderStatusHistory((int)$order['id']);
        $title = 'Đơn '.$order['order_code'].' | Flora';
        $cartCount = ProductModel::cartCount($this->conn, $userId);
        $categories = CategoryModel::all($this->conn);
        require APP_ROOT . '/app/views/layouts/header.php';
        require APP_ROOT . '/app/views/orders/detail.php';
        require APP_ROOT . '/app/views/layouts/footer.php';
    }
    public function cancel(): void
    {
        flora_catalog_post();
        try { $id=flora_catalog_id('order_id'); } catch (DomainException) { http_response_code(400); exit('Mã đơn không hợp lệ.'); } $actor=Auth::user();
        // Che mã đơn người khác ở đường dẫn phía khách.
        if (!$this->orders->findByIdAndUser($id,(int)$actor['id'])) flora_catalog_notFound();
        flora_catalog_handle(function () use ($id,$actor) {
            $result=(new OrderService($this->conn))->cancelOrder($id,(int)$actor['id'],$actor['role'],flora_catalog_text('reason'));
            flora_catalog_success($result['message']);
            flora_catalog_redirect('order_detail',['id'=>$id]);
        },'order_detail',['id'=>$id]);
    }
}
