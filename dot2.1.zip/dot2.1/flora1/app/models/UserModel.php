<?php

declare(strict_types=1);

final class UserModel
{
    public function __construct(private mysqli $conn) {}

    public function findByEmail(string $email): ?array
    {
        $stmt = $this->conn->prepare(
            'SELECT id, full_name, email, password_hash, role, status FROM users WHERE email = ? LIMIT 1'
        );
        $stmt->bind_param('s', $email);
        $stmt->execute();
        $user = $stmt->get_result()->fetch_assoc();
        $stmt->close();
        return $user ?: null;
    }

    public function createCustomer(string $name, string $email, string $hash): int
    {
        $stmt = $this->conn->prepare(
            "INSERT INTO users (full_name, email, password_hash, role, status) VALUES (?, ?, ?, 'customer', 'active')"
        );
        $stmt->bind_param('sss', $name, $email, $hash);
        $stmt->execute();
        $id = (int) $this->conn->insert_id;
        $stmt->close();
        return $id;
    }
    public function findById(int $id): ?array
    {
        $stmt = $this->conn->prepare(
            'SELECT id, full_name, email, role, status
            FROM users
            WHERE id = ?
            LIMIT 1'
        );

        $stmt->bind_param('i', $id);
        $stmt->execute();

        $user = $stmt->get_result()->fetch_assoc();
        $stmt->close();

        return $user ?: null;
    }
}
