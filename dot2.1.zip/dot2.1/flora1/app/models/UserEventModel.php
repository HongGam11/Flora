<?php
/** Phụ trách: TV2 phối hợp TV4. Giao tiếp ghi thêm giỏ cho D7 đợt 1. */
final class UserEventModel
{
    public function __construct(private mysqli $db) {}

    public function logProductView(?int $userId, string $sessionKey, int $productId): void
    {
        $this->validateContext($userId, $sessionKey, $productId);
        $stmt = $this->db->prepare("INSERT INTO user_events
            (user_id, session_key, event_type, product_id, search_keyword)
            VALUES (?, ?, 'view_product', ?, NULL)");
        $stmt->bind_param('isi', $userId, $sessionKey, $productId);
        $stmt->execute();
        $stmt->close();
    }

    public function logSearch(?int $userId, string $sessionKey, string $keyword): void
    {
        $keyword = trim($keyword);
        $keywordLength = function_exists('mb_strlen')
            ? mb_strlen($keyword, 'UTF-8')
            : preg_match_all('/./us', $keyword);
        if ($keyword === '' || preg_match('//u', $keyword) !== 1
            || $keywordLength === false || $keywordLength > 255) {
            throw new InvalidArgumentException('Từ khóa tìm kiếm không hợp lệ.');
        }
        $this->validateContext($userId, $sessionKey);
        $stmt = $this->db->prepare("INSERT INTO user_events
            (user_id, session_key, event_type, product_id, search_keyword)
            VALUES (?, ?, 'search', NULL, ?)");
        $stmt->bind_param('iss', $userId, $sessionKey, $keyword);
        $stmt->execute();
        $stmt->close();
    }

    public function logAddToCart(int $userId, string $sessionKey, int $productId): void
    {
        $this->validateContext($userId, $sessionKey, $productId);
        if ($userId === null || $userId < 1) {
            throw new InvalidArgumentException('Thông tin sự kiện thêm giỏ không hợp lệ.');
        }
        $stmt=$this->db->prepare("INSERT INTO user_events
            (user_id, session_key, event_type, product_id, search_keyword)
            VALUES (?, ?, 'add_to_cart', ?, NULL)");
        $stmt->bind_param('isi',$userId,$sessionKey,$productId);
        $stmt->execute(); $stmt->close();
    }

    private function validateContext(?int $userId, string $sessionKey, ?int $productId = null): void
    {
        if (($userId !== null && $userId < 1)
            || $sessionKey === ''
            || strlen($sessionKey) > 64
            || ($productId !== null && $productId < 1)) {
            throw new InvalidArgumentException('Thông tin sự kiện không hợp lệ.');
        }
    }
}
