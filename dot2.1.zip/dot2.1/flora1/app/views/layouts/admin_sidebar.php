<?php
$adminCurrentRoute = isset($_GET['route']) && is_string($_GET['route'])
    ? $_GET['route']
    : '';

$adminMenuItems = [
    'admin_dashboard'  => ['label' => 'Tổng quan', 'icon' => '<rect x="3" y="3" width="7" height="7" rx="1.5"/><rect x="14" y="3" width="7" height="7" rx="1.5"/><rect x="3" y="14" width="7" height="7" rx="1.5"/><rect x="14" y="14" width="7" height="7" rx="1.5"/>'],
    'admin_categories' => ['label' => 'Danh mục', 'icon' => '<path d="M4 5.5h7v7H4zM13 5.5h7v7h-7zM4 14.5h7v5H4zM13 14.5h7v5h-7z"/>'],
    'admin_products'   => ['label' => 'Sản phẩm', 'icon' => '<path d="m12 3 8 4.5v9L12 21l-8-4.5v-9L12 3Z"/><path d="m4.5 7.8 7.5 4.3 7.5-4.3M12 12v8.5"/>'],
    'admin_variants'   => ['label' => 'Biến thể và kho', 'icon' => '<path d="M4 7.5 12 3l8 4.5v9L12 21l-8-4.5v-9Z"/><path d="m4.5 7.8 7.5 4.3 7.5-4.3M12 12v8.5M8 5.2l8 4.6"/>'],
    'admin_orders'     => ['label' => 'Đơn hàng', 'icon' => '<path d="M5 4h14l1 17H4L5 4Z"/><path d="M9 8V6a3 3 0 0 1 6 0v2M8 12h8"/>'],
    'admin_coupons'    => ['label' => 'Mã giảm giá', 'icon' => '<path d="M3 8V4h17v5a3 3 0 0 0 0 6v5H3v-4a3 3 0 0 0 0-6V8Z"/><path d="m9 14 6-6M9 8h.01M15 14h.01"/>'],
    'admin_users'      => ['label' => 'Tài khoản', 'icon' => '<circle cx="9" cy="8" r="3.5"/><path d="M3 20a6 6 0 0 1 12 0M16 5.2a3.5 3.5 0 0 1 0 6.6M17 15a5 5 0 0 1 4 5"/>'],
    'admin_reports'    => ['label' => 'Báo cáo', 'icon' => '<path d="M4 20V10M10 20V4M16 20v-7M22 20H2"/>'],
];
?>

<aside class="admin-sidebar">
    <div class="admin-sidebar-heading">
        <span class="admin-sidebar-kicker">FLORA COMMERCE</span>
        <span class="admin-sidebar-title">Không gian quản trị</span>
    </div>
    <p class="admin-sidebar-label">MENU CHÍNH</p>
    <nav aria-label="Menu quản trị">
        <?php foreach ($adminMenuItems as $menuRoute => $menuItem): ?>
            <?php
            $menuActive = $adminCurrentRoute === $menuRoute
                || str_starts_with(
                    $adminCurrentRoute,
                    $menuRoute . '_'
                );
            ?>

            <a
                class="admin-menu-link<?= $menuActive ? ' is-active' : '' ?>"
                href="index.php?route=<?= e($menuRoute) ?>"
                <?= $menuActive ? 'aria-current="page"' : '' ?>
            >
                <svg class="admin-menu-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.65" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><?= $menuItem['icon'] ?></svg>
                <span><?= e($menuItem['label']) ?></span>
                <?php if ($menuActive): ?><i class="admin-menu-indicator" aria-hidden="true"></i><?php endif; ?>
            </a>
        <?php endforeach; ?>
    </nav>
    <div class="admin-sidebar-footer">
        <span class="admin-sidebar-status" aria-hidden="true"></span>
        <div><strong>Flora Administration</strong><small>Fashion · Store · Service</small></div>
    </div>
</aside>

<main class="admin-content">
    <?php require APP_ROOT . '/app/views/layouts/messages.php'; ?>