        <footer class="admin-page-footer">
            Flora · Hệ thống quản trị cửa hàng
        </footer>
    </main>
</div>

<script src="assets/js/common.js?v=<?= (int) filemtime(APP_ROOT . '/assets/js/common.js') ?>" defer></script>
</body>
</html>