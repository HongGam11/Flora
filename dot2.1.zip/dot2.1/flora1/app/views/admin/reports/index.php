<?php
$from ??= '';
$to ??= '';
$period ??= '30d';
$overview ??= ['completed_orders' => 0, 'customers' => 0, 'merchandise_revenue' => 0];
$previousOverview ??= ['completed_orders' => 0, 'customers' => 0, 'merchandise_revenue' => 0];
$dailySales ??= [];
$orderStatuses ??= [];
$previousOrderStatuses ??= [];
$categorySales ??= [];
$completedOrders ??= [];
$bestSelling ??= [];
$slowSelling ??= [];
$lowStock ??= [];
$eventSummary ??= [];
$viewedProducts ??= [];
$cartedProducts ??= [];
$searches ??= [];

$eventLabels = [
    'view_product' => 'Lượt xem sản phẩm',
    'search' => 'Tìm kiếm',
    'add_to_cart' => 'Lượt thêm giỏ',
];
$statusLabels = [
    'pending' => 'Chờ xác nhận',
    'confirmed' => 'Đang xử lý',
    'shipping' => 'Đang giao',
    'completed' => 'Hoàn thành',
    'cancelled' => 'Đã hủy',
];
$statusCounts = array_fill_keys(array_keys($statusLabels), 0);
foreach ($orderStatuses as $statusRow) {
    if (isset($statusCounts[$statusRow['status']])) {
        $statusCounts[$statusRow['status']] = (int) $statusRow['order_count'];
    }
}
$previousStatusCounts = array_fill_keys(array_keys($statusLabels), 0);
foreach ($previousOrderStatuses as $statusRow) {
    if (isset($previousStatusCounts[$statusRow['status']])) {
        $previousStatusCounts[$statusRow['status']] = (int) $statusRow['order_count'];
    }
}
$totalOrders = array_sum($statusCounts);
$previousTotalOrders = array_sum($previousStatusCounts);
$averageOrderValue = (int) $overview['completed_orders'] > 0
    ? (float) $overview['merchandise_revenue'] / (int) $overview['completed_orders']
    : 0;
$previousAverageOrderValue = (int) $previousOverview['completed_orders'] > 0
    ? (float) $previousOverview['merchandise_revenue'] / (int) $previousOverview['completed_orders']
    : 0;
$statusTotal = array_sum($statusCounts);
$sellingProducts = array_values(array_filter(
    $bestSelling,
    static fn(array $product): bool => (int) $product['units_sold'] > 0
));
$maxProductUnits = max([1, ...array_map(static fn(array $product): int => (int) $product['units_sold'], array_slice($sellingProducts, 0, 5))]);
$maxCategoryRevenue = max([1, ...array_map(static fn(array $category): float => (float) $category['merchandise_revenue'], $categorySales)]);
$topProduct = $sellingProducts[0] ?? null;
$topCategory = isset($categorySales[0]) && (float) $categorySales[0]['merchandise_revenue'] > 0
    ? $categorySales[0]
    : null;
$trendJson = json_encode($dailySales, JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_AMP | JSON_HEX_QUOT);
$trendJson = $trendJson === false ? '[]' : $trendJson;
$changePercent = static function (float $current, float $previous): ?float {
    if ($previous == 0.0) {
        return $current == 0.0 ? 0.0 : null;
    }
    return (($current - $previous) / abs($previous)) * 100;
};
$renderChange = static function (?float $change): string {
    if ($change === null) {
        return '<span class="report-change is-neutral">Chưa có kỳ trước</span>';
    }
    $direction = $change > 0 ? 'is-up' : ($change < 0 ? 'is-down' : 'is-neutral');
    $symbol = $change > 0 ? '+' : '';
    return '<span class="report-change ' . $direction . '">' . $symbol . number_format($change, 1, ',', '.') . '% <small>so với kỳ trước</small></span>';
};
?>
<section class="admin-card tv3-catalog flora-reports">
    <header class="report-heading report-animate">
        <div>
            <p class="report-eyebrow">FLORA <span>/</span> PHÂN TÍCH KINH DOANH</p>
            <h1>Báo cáo kinh doanh</h1>
            <p class="report-subtitle">Theo dõi và phân tích hiệu quả hoạt động kinh doanh của Flora</p>
        </div>
        <div class="report-export">
            <button type="button" class="report-button report-button-quiet" data-export-csv>Xuất Excel</button>
            <button type="button" class="report-button report-button-primary" data-export-pdf>Xuất PDF</button>
        </div>
    </header>

    <form method="get" action="index.php" class="report-filter report-animate">
        <input type="hidden" name="route" value="admin_reports">
        <label class="report-period-label">Khoảng thời gian
            <select name="period" id="report-period">
                <option value="today" <?= $period === 'today' ? 'selected' : '' ?>>Hôm nay</option>
                <option value="7d" <?= $period === '7d' ? 'selected' : '' ?>>7 ngày gần nhất</option>
                <option value="30d" <?= $period === '30d' ? 'selected' : '' ?>>30 ngày gần nhất</option>
                <option value="90d" <?= $period === '90d' ? 'selected' : '' ?>>90 ngày gần nhất</option>
                <option value="custom" <?= $period === 'custom' ? 'selected' : '' ?>>Tùy chỉnh thời gian</option>
            </select>
        </label>
        <div class="report-custom-dates" id="report-custom-dates">
            <label>Từ ngày (UTC)<input type="date" name="from" value="<?= e($from) ?>" required></label>
            <label>Đến ngày (UTC)<input type="date" name="to" value="<?= e($to) ?>" required></label>
        </div>
        <button type="submit" class="report-button report-button-primary">Cập nhật báo cáo</button>
    </form>

    <div class="report-kpis report-animate">
        <article class="report-kpi">
            <div class="report-kpi-top"><span>Doanh thu thuần</span><span class="report-kpi-icon" aria-hidden="true">₫</span></div>
            <strong class="report-kpi-value" data-count="<?= e($overview['merchandise_revenue']) ?>" data-format="money">0</strong>
            <?= $renderChange($changePercent((float) $overview['merchandise_revenue'], (float) $previousOverview['merchandise_revenue'])) ?>
            <svg class="report-sparkline" data-sparkline="revenue" aria-hidden="true"></svg>
        </article>
        <article class="report-kpi">
            <div class="report-kpi-top"><span>Tổng đơn hàng</span><span class="report-kpi-icon" aria-hidden="true">↗</span></div>
            <strong class="report-kpi-value" data-count="<?= $totalOrders ?>" data-format="number">0</strong>
            <?= $renderChange($changePercent((float) $totalOrders, (float) $previousTotalOrders)) ?>
            <svg class="report-sparkline" data-sparkline="orders" aria-hidden="true"></svg>
        </article>
        <article class="report-kpi">
            <div class="report-kpi-top"><span>Đơn hoàn tất</span><span class="report-kpi-icon" aria-hidden="true">✓</span></div>
            <strong class="report-kpi-value" data-count="<?= (int) $overview['completed_orders'] ?>" data-format="number">0</strong>
            <?= $renderChange($changePercent((float) $overview['completed_orders'], (float) $previousOverview['completed_orders'])) ?>
            <svg class="report-sparkline" data-sparkline="orders" aria-hidden="true"></svg>
        </article>
        <article class="report-kpi">
            <div class="report-kpi-top"><span>Giá trị đơn TB</span><span class="report-kpi-icon" aria-hidden="true">⌁</span></div>
            <strong class="report-kpi-value" data-count="<?= e($averageOrderValue) ?>" data-format="money">0</strong>
            <?= $renderChange($changePercent($averageOrderValue, $previousAverageOrderValue)) ?>
            <svg class="report-sparkline" data-sparkline="revenue" aria-hidden="true"></svg>
        </article>
    </div>
    <p class="report-footnote">Doanh thu chỉ tính đơn hoàn tất theo ngày hoàn tất, đã trừ giảm giá đơn và không gồm phí giao hàng. So sánh với kỳ liền trước có cùng số ngày.</p>

    <div class="report-main-grid">
        <section class="report-panel report-trend-panel report-animate">
            <div class="report-section-heading">
                <div>
                    <p class="report-eyebrow">HIỆU SUẤT</p>
                    <h2>Xu hướng kinh doanh</h2>
                </div>
                <div class="report-chart-controls">
                    <label class="sr-only" for="report-metric">Chỉ số biểu đồ</label>
                    <select id="report-metric"><option value="revenue">Doanh thu</option><option value="orders">Đơn hoàn tất</option></select>
                    <label class="sr-only" for="report-grouping">Cách nhóm dữ liệu</label>
                    <select id="report-grouping"><option value="day">Ngày</option><option value="week">Tuần</option><option value="month">Tháng</option></select>
                </div>
            </div>
            <div class="report-chart-summary"><strong id="report-chart-total">—</strong><span id="report-chart-caption">Tổng doanh thu trong kỳ</span></div>
            <div class="report-chart-wrap" id="report-chart" role="group" aria-label="Biểu đồ xu hướng kinh doanh">
                <p class="report-empty">Đang tải biểu đồ…</p>
            </div>
            <div class="report-chart-tooltip" id="report-chart-tooltip" role="status" aria-live="polite"></div>
        </section>

        <section class="report-panel report-status-panel report-animate">
            <div class="report-section-heading">
                <div><p class="report-eyebrow">ĐƠN HÀNG</p><h2>Trạng thái đơn</h2></div>
            </div>
            <p class="report-panel-note">Đơn tạo trong khoảng thời gian đã chọn</p>
            <div class="report-status-overview">
                <div class="report-donut" data-donut aria-label="Tỷ lệ trạng thái đơn hàng">
                    <div><strong><?= number_format($statusTotal) ?></strong><span>đơn hàng</span></div>
                </div>
                <ul class="report-legend">
                    <?php foreach ($statusLabels as $status => $label): ?>
                        <?php $statusPercent = $statusTotal > 0 ? ($statusCounts[$status] / $statusTotal) * 100 : 0; ?>
                        <li>
                            <span class="report-legend-label"><i class="report-status-dot status-<?= e($status) ?>"></i><?= e($label) ?></span>
                            <strong><?= number_format($statusCounts[$status]) ?></strong>
                            <span class="report-status-percent"><?= number_format($statusPercent, 1, ',', '.') ?>%</span>
                        </li>
                    <?php endforeach; ?>
                </ul>
            </div>
        </section>
    </div>

    <div class="report-analysis-grid">
        <section class="report-panel report-animate">
            <div class="report-section-heading">
                <div><p class="report-eyebrow">SẢN PHẨM</p><h2>Sản phẩm bán chạy</h2></div>
                <span class="report-period-caption">Top 5 trong kỳ</span>
            </div>
            <?php if ($sellingProducts): ?>
                <div class="report-product-list">
                    <?php foreach (array_slice($sellingProducts, 0, 5) as $index => $product): ?>
                        <?php $productImage = $product['main_image'] ?: 'assets/images/no-image.svg'; ?>
                        <article class="report-product">
                            <span class="report-product-rank"><?= str_pad((string) ($index + 1), 2, '0', STR_PAD_LEFT) ?></span>
                            <img src="<?= e($productImage) ?>" alt="" loading="lazy">
                            <div class="report-product-info">
                                <strong><?= e($product['name']) ?></strong>
                                <span><?= number_format((int) $product['units_sold']) ?> sản phẩm đã bán</span>
                                <div class="report-product-bar"><i style="width: <?= min(100, ((int) $product['units_sold'] / $maxProductUnits) * 100) ?>%"></i></div>
                            </div>
                            <strong class="report-product-revenue"><?= flora_money($product['merchandise_revenue']) ?></strong>
                        </article>
                    <?php endforeach; ?>
                </div>
            <?php else: ?><p class="report-empty">Chưa có sản phẩm bán ra trong kỳ này.</p><?php endif; ?>
        </section>

        <section class="report-panel report-animate">
            <div class="report-section-heading">
                <div><p class="report-eyebrow">DANH MỤC</p><h2>Doanh thu theo danh mục</h2></div>
            </div>
            <?php if ($categorySales): ?>
                <div class="report-category-list">
                    <?php foreach ($categorySales as $category): ?>
                        <div class="report-category-row">
                            <div><span><?= e($category['category_name']) ?></span><strong><?= flora_money($category['merchandise_revenue']) ?></strong></div>
                            <div class="report-category-bar"><i style="width: <?= min(100, ((float) $category['merchandise_revenue'] / $maxCategoryRevenue) * 100) ?>%"></i></div>
                        </div>
                    <?php endforeach; ?>
                </div>
                <p class="report-footnote">Mã giảm giá đơn được phân bổ theo tỷ trọng tiền hàng từng danh mục.</p>
            <?php else: ?><p class="report-empty">Chưa có doanh thu danh mục trong kỳ này.</p><?php endif; ?>
        </section>
    </div>

    <section class="report-summary report-animate">
        <div class="report-summary-title"><p class="report-eyebrow">TÓM TẮT</p><h2>Tổng quan hiệu quả</h2></div>
        <div class="report-summary-items">
            <article><span>Sản phẩm nổi bật</span><strong><?= $topProduct ? e($topProduct['name']) : 'Chưa có dữ liệu' ?></strong><small><?= $topProduct ? number_format((int) $topProduct['units_sold']) . ' sản phẩm đã bán' : 'Bắt đầu ghi nhận khi có đơn hoàn tất' ?></small></article>
            <article><span>Danh mục dẫn đầu</span><strong><?= $topCategory ? e($topCategory['category_name']) : 'Chưa có dữ liệu' ?></strong><small><?= $topCategory ? flora_money($topCategory['merchandise_revenue']) . ' doanh thu thuần' : 'Chưa phát sinh doanh thu trong kỳ' ?></small></article>
            <article><span>Chỉ số cần chú ý</span><strong><?= count($lowStock) > 0 ? number_format(count($lowStock)) . ' biến thể sắp hết hàng' : 'Tồn kho ổn định' ?></strong><small><?= count($lowStock) > 0 ? 'Các biến thể có tồn hiện tại không quá 5' : 'Không có biến thể active dưới ngưỡng 5' ?></small></article>
            <article><span>Khách đặt đơn</span><strong><?= number_format((int) $overview['customers']) ?></strong><small>Khách hàng có đơn hoàn tất trong kỳ</small></article>
        </div>
    </section>

    <details class="report-details report-animate">
        <summary>Phân tích chi tiết và danh sách đơn</summary>
        <div class="report-details-content">
            <section>
                <h2>Đơn hoàn tất trong kỳ</h2>
                <?php if ($completedOrders): ?>
                    <div class="tv3-scroll"><table>
                        <thead><tr><th>Mã đơn</th><th>Khách hàng</th><th>Hoàn tất (UTC)</th><th>Tiền hàng</th></tr></thead>
                        <tbody><?php foreach ($completedOrders as $order): ?>
                            <tr><td><?= e($order['order_code']) ?></td><td><?= e($order['full_name']) ?></td>
                                <td><?= e($order['completed_at']) ?></td><td><?= flora_money($order['merchandise_amount']) ?></td></tr>
                        <?php endforeach; ?></tbody>
                    </table></div>
                    <p class="report-footnote">Hiển thị tối đa 100 đơn mới hoàn tất; KPI và doanh thu tính toàn bộ kỳ lọc.</p>
                <?php else: ?><p class="report-empty">Không có đơn hoàn tất trong kỳ.</p><?php endif; ?>
            </section>

            <div class="report-columns">
                <section><h2>Bảng xếp hạng bán chạy (tối đa 10)</h2><div class="tv3-scroll"><table>
                    <thead><tr><th>Sản phẩm</th><th>Số lượng</th><th>Số đơn</th><th>Doanh thu</th></tr></thead>
                    <tbody><?php if ($bestSelling): foreach ($bestSelling as $product): ?>
                        <tr><td><?= e($product['name']) ?></td><td><?= number_format((int) $product['units_sold']) ?></td><td><?= number_format((int) $product['order_count']) ?></td><td><?= flora_money($product['merchandise_revenue']) ?></td></tr>
                    <?php endforeach; else: ?><tr><td colspan="4">Chưa có sản phẩm.</td></tr><?php endif; ?></tbody>
                </table></div></section>
                <section><h2>Bán thấp (gồm cả 0)</h2><div class="tv3-scroll"><table>
                    <thead><tr><th>Sản phẩm</th><th>Trạng thái</th><th>Số lượng</th></tr></thead>
                    <tbody><?php if ($slowSelling): foreach ($slowSelling as $product): ?>
                        <tr><td><?= e($product['name']) ?></td><td><?= e($product['status']) ?></td><td><?= number_format((int) $product['units_sold']) ?></td></tr>
                    <?php endforeach; else: ?><tr><td colspan="3">Chưa có sản phẩm.</td></tr><?php endif; ?></tbody>
                </table></div></section>
                <section><h2>Tồn thấp (tồn hiện tại ≤ 5)</h2><div class="tv3-scroll"><table>
                    <thead><tr><th>Sản phẩm</th><th>Màu</th><th>Kích thước</th><th>Tồn hiện tại</th></tr></thead>
                    <tbody><?php if ($lowStock): foreach ($lowStock as $variant): ?>
                        <tr><td><?= e($variant['product_name']) ?></td><td><?= e($variant['color_name']) ?></td><td><?= e($variant['size_name']) ?></td><td><?= number_format((int) $variant['stock']) ?></td></tr>
                    <?php endforeach; else: ?><tr><td colspan="4">Không có biến thể active có tồn kho ≤ 5.</td></tr><?php endif; ?></tbody>
                </table></div></section>
            </div>

            <section>
                <h2>Sự kiện, người và đơn hoàn tất</h2>
                <p class="report-footnote">Khách chưa đăng nhập được đếm theo session. Đơn tìm kiếm ghép với tài khoản đã tìm trong kỳ; đơn xem/thêm giỏ là đơn hoàn tất có sản phẩm tương ứng.</p>
                <div class="tv3-scroll"><table>
                    <thead><tr><th>Loại sự kiện</th><th>Số sự kiện</th><th>Số người</th><th>Số đơn</th></tr></thead>
                    <tbody><?php if ($eventSummary): foreach ($eventSummary as $row): ?>
                        <tr><td><?= e($eventLabels[$row['event_type']] ?? $row['event_type']) ?></td><td><?= number_format((int) $row['event_count']) ?></td><td><?= number_format((int) $row['people_count']) ?></td><td><?= number_format((int) $row['order_count']) ?></td></tr>
                    <?php endforeach; else: ?><tr><td colspan="4">Chưa ghi nhận sự kiện trong kỳ.</td></tr><?php endif; ?></tbody>
                </table></div>
            </section>

            <div class="report-columns">
                <?php foreach (['Sản phẩm được xem' => $viewedProducts, 'Sản phẩm được thêm giỏ' => $cartedProducts] as $sectionTitle => $products): ?>
                    <section><h2><?= e($sectionTitle) ?></h2><div class="tv3-scroll"><table>
                        <thead><tr><th>Sản phẩm</th><th>Sự kiện</th><th>Người</th><th>Đơn</th></tr></thead>
                        <tbody><?php if ($products): foreach ($products as $product): ?>
                            <tr><td><?= e($product['product_name']) ?></td><td><?= number_format((int) $product['event_count']) ?></td><td><?= number_format((int) $product['people_count']) ?></td><td><?= number_format((int) $product['order_count']) ?></td></tr>
                        <?php endforeach; else: ?><tr><td colspan="4">Chưa có dữ liệu.</td></tr><?php endif; ?></tbody>
                    </table></div></section>
                <?php endforeach; ?>
            </div>

            <section><h2>Từ khóa tìm kiếm</h2><div class="tv3-scroll"><table>
                <thead><tr><th>Từ khóa</th><th>Sự kiện</th><th>Người</th><th>Đơn hoàn tất</th></tr></thead>
                <tbody><?php if ($searches): foreach ($searches as $search): ?>
                    <tr><td><?= e($search['search_keyword']) ?></td><td><?= number_format((int) $search['event_count']) ?></td><td><?= number_format((int) $search['people_count']) ?></td><td><?= number_format((int) $search['order_count']) ?></td></tr>
                <?php endforeach; else: ?><tr><td colspan="4">Chưa có từ khóa tìm kiếm.</td></tr><?php endif; ?></tbody>
            </table></div></section>
        </div>
    </details>
</section>
<script>
(() => {
    const series = <?= $trendJson ?>;
    const reportRoot = document.querySelector('.flora-reports');
    if (!reportRoot) return;

    const formatNumber = value => new Intl.NumberFormat('vi-VN', { maximumFractionDigits: 0 }).format(value);
    const formatMoney = value => `${formatNumber(value)}₫`;
    const periodSelect = document.getElementById('report-period');
    const dateWrap = document.getElementById('report-custom-dates');
    const customInputs = dateWrap.querySelectorAll('input');
    const updatePeriodFields = (submitPreset = false) => {
        const custom = periodSelect.value === 'custom';
        dateWrap.hidden = !custom;
        customInputs.forEach(input => { input.disabled = !custom; });
        if (!custom && submitPreset) periodSelect.form.requestSubmit();
    };
    periodSelect.addEventListener('change', () => updatePeriodFields(true));
    updatePeriodFields();

    const reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    document.querySelectorAll('.report-kpi-value').forEach(element => {
        const target = Number(element.dataset.count || 0);
        const money = element.dataset.format === 'money';
        const start = performance.now();
        const duration = reduceMotion ? 0 : 850;
        const tick = now => {
            const progress = duration === 0 ? 1 : Math.min(1, (now - start) / duration);
            const eased = 1 - Math.pow(1 - progress, 3);
            element.textContent = money ? formatMoney(target * eased) : formatNumber(target * eased);
            if (progress < 1) requestAnimationFrame(tick);
        };
        requestAnimationFrame(tick);
    });

    const metricSelect = document.getElementById('report-metric');
    const groupingSelect = document.getElementById('report-grouping');
    const chart = document.getElementById('report-chart');
    const tooltip = document.getElementById('report-chart-tooltip');
    const chartTotal = document.getElementById('report-chart-total');
    const chartCaption = document.getElementById('report-chart-caption');
    const aggregate = (grouping, metric) => {
        const buckets = new Map();
        const startDate = new Date('<?= e($from) ?>T00:00:00Z');
        const endDate = new Date('<?= e($to) ?>T00:00:00Z');
        for (const date = new Date(startDate); date <= endDate; date.setUTCDate(date.getUTCDate() + 1)) {
            let key = date.toISOString().slice(0, 10);
            if (grouping === 'week') {
                const weekStart = new Date(date);
                weekStart.setUTCDate(date.getUTCDate() - ((date.getUTCDay() + 6) % 7));
                key = weekStart.toISOString().slice(0, 10);
            } else if (grouping === 'month') {
                key = key.slice(0, 7);
            }
            if (!buckets.has(key)) buckets.set(key, { key, revenue: 0, orders: 0 });
        }
        series.forEach(row => {
            const date = new Date(`${row.report_date}T00:00:00Z`);
            let key = row.report_date;
            if (grouping === 'week') {
                const weekStart = new Date(date);
                weekStart.setUTCDate(date.getUTCDate() - ((date.getUTCDay() + 6) % 7));
                key = weekStart.toISOString().slice(0, 10);
            } else if (grouping === 'month') {
                key = row.report_date.slice(0, 7);
            }
            const existing = buckets.get(key) || { key, revenue: 0, orders: 0 };
            existing.revenue += Number(row.merchandise_revenue || 0);
            existing.orders += Number(row.order_count || 0);
            buckets.set(key, existing);
        });
        return [...buckets.values()].map(point => ({ ...point, value: point[metric] }));
    };
    const renderChart = () => {
        const metric = metricSelect.value;
        const grouping = groupingSelect.value;
        const points = aggregate(grouping, metric);
        const total = points.reduce((sum, point) => sum + point.value, 0);
        const currency = metric === 'revenue';
        chartTotal.textContent = currency ? formatMoney(total) : formatNumber(total);
        chartCaption.textContent = currency ? 'Tổng doanh thu trong kỳ' : 'Tổng đơn hoàn tất trong kỳ';
        if (points.length === 0 || points.every(point => point.value === 0)) {
            chart.innerHTML = '<p class="report-empty">Chưa có dữ liệu trong khoảng thời gian này.</p>';
            return;
        }

        const width = Math.max(chart.clientWidth || 640, 320);
        const height = 250;
        const padding = { top: 16, right: 12, bottom: 34, left: 12 };
        const max = points.reduce((largest, point) => Math.max(largest, point.value), 1);
        const chartWidth = width - padding.left - padding.right;
        const chartHeight = height - padding.top - padding.bottom;
        const visiblePoints = points.length > 240
            ? points.filter((_, index) => index === 0 || index === points.length - 1 || index % Math.ceil(points.length / 240) === 0)
            : points;
        const coords = visiblePoints.map((point, index) => ({
            ...point,
            x: padding.left + (visiblePoints.length === 1 ? chartWidth / 2 : index * chartWidth / (visiblePoints.length - 1)),
            y: padding.top + chartHeight - (point.value / max) * chartHeight
        }));
        const path = coords.map((point, index) => `${index ? 'L' : 'M'} ${point.x} ${point.y}`).join(' ');
        const area = `${path} L ${coords[coords.length - 1].x} ${height - padding.bottom} L ${coords[0].x} ${height - padding.bottom} Z`;
        const step = Math.max(1, Math.ceil(coords.length / 5));
        const labels = coords.filter((_, index) => index % step === 0 || index === coords.length - 1);
        const grid = [0, 1, 2, 3].map(index => {
            const y = padding.top + chartHeight * index / 3;
            return `<line class="report-grid-line" x1="${padding.left}" y1="${y}" x2="${width - padding.right}" y2="${y}"/>`;
        }).join('');
        const circles = coords.map((point, index) => `<circle class="report-chart-point" tabindex="0" role="img" aria-label="${point.key}: ${currency ? formatMoney(point.value) : formatNumber(point.value)}" data-index="${index}" cx="${point.x}" cy="${point.y}" r="4"><title>${point.key}: ${currency ? formatMoney(point.value) : formatNumber(point.value)}</title></circle>`).join('');
        const xLabels = labels.map(point => `<text class="report-axis-label" x="${point.x}" y="${height - 8}" text-anchor="middle">${point.key}</text>`).join('');
        chart.innerHTML = `<svg class="report-chart-svg" viewBox="0 0 ${width} ${height}" role="presentation" preserveAspectRatio="none">${grid}<path class="report-chart-area" d="${area}"/><path class="report-chart-line" d="${path}"/>${circles}${xLabels}</svg>`;
        chart.querySelectorAll('.report-chart-point').forEach(pointElement => {
            const showTooltip = () => {
                const point = coords[Number(pointElement.dataset.index)];
                tooltip.textContent = `${point.key} · ${currency ? formatMoney(point.value) : `${formatNumber(point.value)} đơn`}`;
                tooltip.classList.add('is-visible');
            };
            pointElement.addEventListener('mouseenter', showTooltip);
            pointElement.addEventListener('focus', showTooltip);
            pointElement.addEventListener('mouseleave', () => tooltip.classList.remove('is-visible'));
            pointElement.addEventListener('blur', () => tooltip.classList.remove('is-visible'));
        });
    };
    metricSelect.addEventListener('change', renderChart);
    groupingSelect.addEventListener('change', renderChart);
    renderChart();
    if ('ResizeObserver' in window) new ResizeObserver(renderChart).observe(chart);

    document.querySelectorAll('[data-sparkline]').forEach(svg => {
        const key = svg.dataset.sparkline;
        const values = aggregate('day', key).map(point => point.value);
        if (values.length === 0) return;
        const width = 140, height = 28, max = values.reduce((largest, value) => Math.max(largest, value), 1);
        const visibleValues = values.length > 60
            ? values.filter((_, index) => index === 0 || index === values.length - 1 || index % Math.ceil(values.length / 60) === 0)
            : values;
        const points = visibleValues.map((value, index) => `${visibleValues.length === 1 ? width / 2 : index * width / (visibleValues.length - 1)},${height - 2 - (value / max) * (height - 5)}`);
        svg.setAttribute('viewBox', `0 0 ${width} ${height}`);
        svg.innerHTML = `<polyline points="${points.join(' ')}"/>`;
    });
    document.querySelectorAll('.report-product img').forEach(image => {
        image.addEventListener('error', function fallbackImage() {
            image.removeEventListener('error', fallbackImage);
            image.src = 'assets/images/no-image.svg';
        });
    });

    const statusRows = [...document.querySelectorAll('.report-legend li')];
    const statusColors = ['#d8d8d8', '#b6b6b6', '#858585', '#ee4d2d', '#ece7e4'];
    let statusCursor = 0;
    const statusStops = statusRows.map((row, index) => {
        const count = Number(row.querySelector('strong').textContent.replaceAll('.', '').replaceAll(',', '')) || 0;
        const total = <?= $statusTotal ?>;
        const start = statusCursor;
        statusCursor += total ? count / total * 100 : 0;
        row.querySelector('.report-status-dot').style.backgroundColor = statusColors[index];
        return `${statusColors[index]} ${start}% ${statusCursor}%`;
    });
    document.querySelector('[data-donut]').style.background = statusCursor
        ? `conic-gradient(${statusStops.join(',')})`
        : '#efefef';

    document.querySelector('[data-export-csv]').addEventListener('click', () => {
        const rows = [
            ['Báo cáo kinh doanh'],
            ['Khoảng thời gian', '<?= e($from) ?>', '<?= e($to) ?>'],
            [],
            ['Chỉ số tổng quan', 'Giá trị', 'So với kỳ trước']
        ];
        document.querySelectorAll('.report-kpi').forEach(card => {
            rows.push([
                card.querySelector('.report-kpi-top > span').innerText.trim(),
                card.querySelector('.report-kpi-value').innerText.trim(),
                card.querySelector('.report-change').innerText.trim()
            ]);
        });
        const dailyRevenue = aggregate('day', 'revenue');
        const dailyOrders = new Map(aggregate('day', 'orders').map(point => [point.key, point.value]));
        rows.push([], ['Xu hướng theo ngày', 'Doanh thu', 'Đơn hoàn tất']);
        dailyRevenue.forEach(point => rows.push([point.key, formatMoney(point.value), dailyOrders.get(point.key) || 0]));
        rows.push([], ['Trạng thái đơn', 'Số đơn', 'Tỷ lệ']);
        document.querySelectorAll('.report-legend li').forEach(row => {
            rows.push([
                row.querySelector('.report-legend-label').innerText.trim(),
                row.querySelector('strong').innerText.trim(),
                row.querySelector('.report-status-percent').innerText.trim()
            ]);
        });
        rows.push([], ['Doanh thu theo danh mục', 'Doanh thu']);
        document.querySelectorAll('.report-category-row').forEach(row => {
            rows.push([
                row.querySelector('span').innerText.trim(),
                row.querySelector('strong').innerText.trim()
            ]);
        });
        rows.push([], ['Sản phẩm bán chạy', 'Đã bán', 'Doanh thu']);
        document.querySelectorAll('.report-product').forEach(row => {
            rows.push([
                row.querySelector('.report-product-info > strong').innerText.trim(),
                row.querySelector('.report-product-info > span').innerText.trim(),
                row.querySelector('.report-product-revenue').innerText.trim()
            ]);
        });
        document.querySelectorAll('.flora-reports table').forEach(table => {
            table.querySelectorAll('tr').forEach(row => {
                rows.push([...row.querySelectorAll('th,td')].map(cell => cell.innerText.trim()));
            });
            rows.push([]);
        });
        const csv = rows.map(row => row.map(value => {
            let text = String(value ?? '');
            if (/^\s*[=+\-@]/.test(text) || /^[\t\r]/.test(text)) text = `'${text}`;
            return `"${text.replaceAll('"', '""')}"`;
        }).join(',')).join('\r\n');
        const blob = new Blob(['\ufeff' + csv], { type: 'text/csv;charset=utf-8' });
        const link = document.createElement('a');
        link.href = URL.createObjectURL(blob);
        link.download = `flora-bao-cao-${'<?= e($from) ?>'}-den-${'<?= e($to) ?>'}.csv`;
        link.click();
        URL.revokeObjectURL(link.href);
    });
    document.querySelector('[data-export-pdf]').addEventListener('click', () => window.print());
})();
</script>
