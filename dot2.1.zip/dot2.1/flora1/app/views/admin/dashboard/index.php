<?php
$from ??= '';
$to ??= '';
$summary ??= ['completed_orders' => 0, 'customers' => 0, 'merchandise_revenue' => 0];
?>
<section class="admin-card tv3-catalog flora-reports">
    <h1>Tổng quan cửa hàng</h1>
    <p>Đơn và doanh thu trong 30 ngày gần nhất (<?= e($from) ?> – <?= e($to) ?> UTC).</p>
    <div class="report-kpis">
        <article><span>Đơn hoàn tất</span><strong><?= number_format((int) $summary['completed_orders']) ?></strong></article>
        <article><span>Khách đặt đơn</span><strong><?= number_format((int) $summary['customers']) ?></strong></article>
        <article><span>Doanh thu hàng hóa</span><strong><?= flora_money($summary['merchandise_revenue']) ?></strong></article>
    </div>
    <p class="report-note">Chỉ tính đơn hoàn tất theo ngày hoàn tất. Doanh thu đã trừ giảm giá đơn và không gồm phí giao hàng.</p>
    <p><a class="tv3-button" href="index.php?route=admin_reports">Mở báo cáo chi tiết</a></p>
</section>
