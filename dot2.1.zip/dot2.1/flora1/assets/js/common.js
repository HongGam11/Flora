"use strict";

document.addEventListener("DOMContentLoaded", function () {
    const dropdowns = Array.from(document.querySelectorAll(".flora-nav-dropdown"));
    const supportsHover = window.matchMedia("(hover: hover) and (pointer: fine)").matches;

    function setDropdownOpen(dropdown, isOpen) {
        const toggle = dropdown.querySelector(".flora-nav-toggle");
        dropdown.classList.toggle("is-open", isOpen);
        if (toggle) toggle.setAttribute("aria-expanded", String(isOpen));
    }

    dropdowns.forEach(function (dropdown) {
        const toggle = dropdown.querySelector(".flora-nav-toggle");

        if (supportsHover) {
            dropdown.addEventListener("pointerenter", function () {
                setDropdownOpen(dropdown, true);
            });
            dropdown.addEventListener("pointerleave", function () {
                if (!dropdown.matches(":focus-within")) setDropdownOpen(dropdown, false);
            });
        }

        dropdown.addEventListener("focusin", function () {
            setDropdownOpen(dropdown, true);
        });
        dropdown.addEventListener("focusout", function () {
            window.setTimeout(function () {
                if (!dropdown.matches(":focus-within") && !dropdown.matches(":hover")) {
                    setDropdownOpen(dropdown, false);
                }
            }, 0);
        });

        if (toggle) {
            toggle.addEventListener("click", function () {
                setDropdownOpen(
                    dropdown,
                    supportsHover || !dropdown.classList.contains("is-open")
                );
            });
        }
    });

    document.addEventListener("pointerdown", function (event) {
        dropdowns.forEach(function (dropdown) {
            if (
                !dropdown.contains(event.target) &&
                (dropdown.classList.contains("is-open") || dropdown.contains(document.activeElement))
            ) {
                if (dropdown.contains(document.activeElement)) {
                    document.activeElement.blur();
                }
                setDropdownOpen(dropdown, false);
            }
        });
    });

    const reduceMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    if (!reduceMotion && "IntersectionObserver" in window) {
        const targets = document.querySelectorAll(
            ".reveal-on-scroll, .flora-site-footer, .admin-content > .admin-card, .admin-page-footer"
        );
        if (targets.length) {
            const observer = new IntersectionObserver(function (entries) {
                entries.forEach(function (entry) {
                    if (entry.isIntersecting) {
                        entry.target.classList.add("is-visible");
                        observer.unobserve(entry.target);
                    }
                });
            }, { threshold: 0.12 });

            targets.forEach(function (target) {
                target.classList.add("reveal-pending");
                observer.observe(target);
            });
        }
    }

    const successMessage = document.querySelector(".flora-alert--success");
    const cartCount = document.getElementById("cart-count");
    if (successMessage && cartCount && successMessage.textContent.toLowerCase().includes("giỏ hàng")) {
        cartCount.classList.add("is-updated");
    }
});
