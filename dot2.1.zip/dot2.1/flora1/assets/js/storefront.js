"use strict";

document.addEventListener("DOMContentLoaded", function () {
    const fallbackImage = "assets/images/no-image.svg";
    document.querySelectorAll(".ph img, .hero-image img, .flora-thumbnail img").forEach(function (image) {
        function useFallback() {
            if (image.dataset.fallbackApplied) return;
            image.dataset.fallbackApplied = "1";
            image.src = fallbackImage;
        }
        image.addEventListener("error", useFallback);
        if (image.complete && image.naturalWidth === 0) useFallback();
    });

    const reduceMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    const supportsHover = window.matchMedia("(hover: hover) and (pointer: fine)").matches;
    if (!reduceMotion && supportsHover) {
        document.querySelectorAll(".grid > .product-card").forEach(function (card) {
            let frame = 0;
            let bounds = null;
            card.addEventListener("pointerenter", function () {
                bounds = card.getBoundingClientRect();
            });

            card.addEventListener("pointermove", function (event) {
                if (!bounds || !bounds.width || !bounds.height) return;
                const x = Math.max(0, Math.min(1, (event.clientX - bounds.left) / bounds.width));
                const y = Math.max(0, Math.min(1, (event.clientY - bounds.top) / bounds.height));

                cancelAnimationFrame(frame);
                frame = requestAnimationFrame(function () {
                    card.style.setProperty("--tilt-x", ((0.5 - y) * 8).toFixed(2) + "deg");
                    card.style.setProperty("--tilt-y", ((x - 0.5) * 10).toFixed(2) + "deg");
                    card.style.setProperty("--glare-x", (x * 100).toFixed(2) + "%");
                    card.style.setProperty("--glare-y", (y * 100).toFixed(2) + "%");
                });
            });

            card.addEventListener("pointerleave", function () {
                cancelAnimationFrame(frame);
                bounds = null;
                card.style.removeProperty("--tilt-x");
                card.style.removeProperty("--tilt-y");
                card.style.removeProperty("--glare-x");
                card.style.removeProperty("--glare-y");
            });
        });
    }

    const detailImage = document.getElementById("detail-image");
    let detailImageAnimation = null;
    function revealDetailImage() {
        if (reduceMotion || !detailImage || typeof detailImage.animate !== "function") return;
        if (detailImageAnimation) detailImageAnimation.cancel();
        detailImageAnimation = detailImage.animate(
            [{ opacity: 0.72, transform: "scale(.99)" }, { opacity: 1, transform: "scale(1)" }],
            { duration: 280, easing: "cubic-bezier(.2, .7, .2, 1)" }
        );
    }

    function setDetailImage(source) {
        if (!detailImage || !source) return;
        const nextSource = new URL(source, window.location.href).href;
        if (detailImage.src === nextSource) return;
        detailImage.addEventListener("load", revealDetailImage, { once: true });
        detailImage.src = source;
    }

    document.querySelectorAll("[data-gallery-src]").forEach(function (button) {
        button.addEventListener("click", function () {
            if (detailImage) {
                delete detailImage.dataset.fallbackApplied;
                setDetailImage(button.dataset.gallerySrc);
            }
        });
    });

    const form = document.getElementById("add-to-cart-form");
    const select = document.getElementById("variant");
    const quantity = document.getElementById("cart-quantity");
    const button = document.getElementById("add-to-cart-button");
    const stockMessage = document.getElementById("variant-stock");
    const priceElement = document.getElementById("variant-price");
    if (!form || !select || !quantity || !button) return;
    const formatter = new Intl.NumberFormat("vi-VN");

    function updateControls() {
        const option = select.options[select.selectedIndex];
        const stock = Number(option?.dataset.stock || 0);
        const canAdd = Boolean(option?.value) && stock > 0;
        button.disabled = !canAdd;
        quantity.disabled = !canAdd;
        if (canAdd) {
            quantity.max = String(stock);
            const amount = Number(quantity.value);
            if (!Number.isInteger(amount) || amount < 1) quantity.value = "1";
            else if (amount > stock) quantity.value = String(stock);
        } else {
            quantity.removeAttribute("max");
        }
        if (stockMessage) {
            stockMessage.textContent = !option?.value ? "Chọn màu và kích thước để xem tồn kho."
                : stock <= 0 ? "Biến thể này hiện đã hết hàng."
                : stock <= 5 ? "Chỉ còn " + stock + " sản phẩm." : "Còn hàng (" + stock + ").";
            stockMessage.className = stock <= 0 && option?.value ? "note out" : "note";
        }
        if (option?.value && priceElement) {
            priceElement.textContent = formatter.format(Number(option.dataset.price)) + "₫";
        }
        if (option?.value && option.dataset.image && detailImage) {
            delete detailImage.dataset.fallbackApplied;
            setDetailImage(option.dataset.image);
        }
    }
    select.addEventListener("change", updateControls);
    form.addEventListener("submit", function (event) {
        const option = select.options[select.selectedIndex];
        const amount = Number(quantity.value);
        const stock = Number(option?.dataset.stock || 0);
        if (!option?.value || !Number.isInteger(amount) || amount < 1 || amount > stock) {
            event.preventDefault();
            if (stockMessage) stockMessage.textContent = "Vui lòng chọn biến thể và số lượng phù hợp với tồn kho.";
        }
    });
    updateControls();
});
