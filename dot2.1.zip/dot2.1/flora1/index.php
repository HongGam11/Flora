<?php
declare(strict_types=1);

require_once __DIR__ . '/app/bootstrap.php';

$route = isset($_GET['route']) && is_string($_GET['route'])
    ? $_GET['route']
    : '';

if ($route === '') {
    if (isset($_GET['product']) && is_scalar($_GET['product'])) {
        $route = 'product-detail';
        $_GET['id'] = (string) $_GET['product'];
    } elseif (
        (isset($_GET['view']) && $_GET['view'] === 'shop')
        || isset($_GET['category'])
        || isset($_GET['q'])
        || isset($_GET['min_price'])
        || isset($_GET['max_price'])
        || isset($_GET['page'])
    ) {
        $route = 'products';
    } else {
        $route = 'home';
    }
}

(new Router())->dispatch($route);
